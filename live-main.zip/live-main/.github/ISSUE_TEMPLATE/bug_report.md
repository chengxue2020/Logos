---	
name: 问题反馈
about: 遇到缺失或模糊不清有错误的频道logo请通过这里提交反馈，我们将尽快补齐或修复。
title: ''
labels: bug
assignees: 

---

## 遇到的问题	
请在此描述您遇到的问题。
